# Dashboard Frontend Assignment

## Run locally
```bash
npm install
npm run dev
```
